import javax.swing.*;
import java.applet.Applet;
import java.io.*;
import java.applet.AudioClip;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Scanner;

// Fied Elahresh
// cyberNINJA.java (name change mid-way in)
// This program is an infinite side scrolling 2d game where the objective is to reach the zombie kill count goal before
// colliding into a mob or killing the bats 5 times, it features another skin, a highscore menu, and keeps track of your
// kills
class Game0 extends JFrame{    // Graphics java frame
    GamePanel game = new GamePanel();
    public Game0(){    // Game method
        super("CyberNINJA");
        add(game);
        pack();
        setVisible(true);
        addWindowListener(new java.awt.event.WindowAdapter(){    // Window Listener from avnoor
            public void windowClosing(java.awt.event.WindowEvent e){    // Avnoor ludhar informed me the window listener
                game.saveInfo();
                System.exit(EXIT_ON_CLOSE);
            }
        });
    }
    public static void main(String[] args){
        Game0 frame = new Game0();
    }
}
class GamePanel extends JPanel implements MouseListener, ActionListener, KeyListener {    // Main class
    private int mx, my, randomLocationZombie, speed, randomLocationBat, offset, score, killCount, killCheckCounter, livesCounter, goalAmount,muteNoise,totalKillCount,scoresNumber;
    private int INTRO = 0, GAME = 1, SHOP = 2, HIGHSCORE = 3, DEADSCREEN = 4;
    private int SCREEN = 0;
    private boolean keys[];
    private String scores, kills,level;
    Timer timer;
    Image bg, deathScreen, headCount, girlNinjaSelect, highScoreIcon, ninjaLocked, playButton, highscoreButton, skinButton, mute, introBackground, backButton,highScoreDisplay;
    private Player player;
    Enemy enemy;
    bat bats;
    Font lives, killCountType,scoreFont;
    ArrayList<Enemy> EnemyArrayList;
    ArrayList<bat> batArrayList;
    ArrayList<Enemy> killCountList;
    Sound sounds;


    public GamePanel() {    // Constructor for the game panel
        addMouseListener(this);    // Loading all my graphics and the variables going to be used
        addKeyListener(this);
        lives = new Font("Futura", Font.BOLD, 24);
        scoreFont = new Font("Futura", Font.BOLD, 24);
        killCountType = new Font("Futura", Font.BOLD, 24);
        bg = new ImageIcon("cyberpunk.png").getImage();
        muteNoise = 0;
        level = "5";
        scores = "0";
        kills = "0";
        backButton = new ImageIcon("GUI/backButton.png").getImage();
        highScoreDisplay = new ImageIcon("GUI/highScoreScreen.png").getImage();
        introBackground = new ImageIcon("GUI/introBackground.png").getImage();
        deathScreen = new ImageIcon("GUI/deathScreen.png").getImage();
        headCount = new ImageIcon("GUI/zombieHead.png").getImage();
        girlNinjaSelect = new ImageIcon("GUI/girlNinjaLocked.png").getImage();
        highScoreIcon = new ImageIcon("GUI/highScoreIcon.png").getImage();
        ninjaLocked = new ImageIcon("GUI/ninjaLocked.png").getImage();
        playButton = new ImageIcon("GUI/playNormal.png").getImage();
        highscoreButton = new ImageIcon("GUI/highscoreNormal.png").getImage();
        skinButton = new ImageIcon("GUI/skinNormal.png").getImage();
        mute = new ImageIcon("GUI/muteOff.png").getImage();
        sounds = new Sound(new File("Sword Slash Sound Effect.wav"), new File("Death sound in Minecraft.wav"), new File("Sliding sound effect.wav"),new File("running footsteps - Sound Effect HD.wav"));
        player = new Player();
        keys = new boolean[KeyEvent.KEY_LAST + 1];
        offset = 0;
        livesCounter = 5;
        killCount = 0;
        score = 0;
        enemy = new Enemy(2200);
        try{
            loadInfo();
        }
        catch(FileNotFoundException e){

        }

        bats = new bat(2700);
        totalKillCount = Integer.parseInt(kills);    //  Setting the totalkillcount to the text file to accumulate total kills
        speed = 10;
        randomLocationZombie = randint(1920, 3080);   // Ensuring a different gameplay experience every time
        randomLocationBat = randint(1920, 3080);
        EnemyArrayList = new ArrayList<>();    // loading in data structures, Object ArrayLists
        batArrayList = new ArrayList<>();
        killCountList = new ArrayList<>();
        batArrayList.add(bats);    // Even though I want to have a unique gameplay experience every time, a tutorial bat and zombie in the beginning is useful
        EnemyArrayList.add(enemy);
        setFocusable(true);
        requestFocus();
        timer = new Timer(20, this);
        timer.start();
    }

    public void actionPerformed(ActionEvent e) {    // Includes the actions performed in my game
        if (SCREEN == GAME) {
            keyInput();
            moveBackground();
            spawnMobs();
            collision();
            countScore();
        }
        repaint();

    }
    public void loadInfo() throws FileNotFoundException{    // FILEIO saving the information to text files, things like highest score, all time kills, and the level you are on
        Scanner inFile = new Scanner(new BufferedReader(new FileReader("scores.txt")));    // Score
        scores = inFile.nextLine();
        inFile.close();


        Scanner inFile2 = new Scanner(new BufferedReader(new FileReader("kills.txt")));    // kills
        kills = inFile2.nextLine();
        inFile2.close();

        Scanner inFile3 = new Scanner(new BufferedReader(new FileReader("level.txt")));    // Level
        level = inFile3.nextLine();
        inFile3.close();
        goalAmount = Integer.parseInt(level);    // Turning the goal amount into the written level information

    }
    public void saveInfo(){    // When closing the window, it saves the information so it can be used next log on
        try {
            PrintWriter outFile = new PrintWriter(
                    new BufferedWriter(new FileWriter("scores.txt")));   // Score being saved
            outFile.println(scoresNumber);
            outFile.close();

            PrintWriter outFile2 = new PrintWriter(
                    new BufferedWriter(new FileWriter("kills.txt")));    // Kills being saved
            outFile2.println(totalKillCount);
            outFile2.close();

            PrintWriter outFile3 = new PrintWriter(
                    new BufferedWriter(new FileWriter("level.txt")));    // Level being saved
            outFile3.println(goalAmount);

            outFile3.close();

        }catch(Exception ex){
            System.out.println(ex);
        }
    }
    public void mouseClicked(MouseEvent e) {
    }    // Required method

    public void mouseEntered(MouseEvent e) {

    }    // Required method

    public void mouseExited(MouseEvent e) {
    }     // Required method

    public void mousePressed(MouseEvent e) {    // Required method where I check for actions regarding the pressing of the mouse
        mx = e.getX();
        my = e.getY();

        if(SCREEN == INTRO && mx > 700 && mx < 1139 && my > 850 && my < 1289){    // g.drawRect(700,850,439,99);
                                                        //g.drawRect(100,850,439,99);
                                                            //g.drawRect(1300,850,439,99);
            SCREEN = GAME;
        }
        else if(SCREEN == INTRO && mx > 100 && mx < 539 && my > 850 && my < 1289){    // Setting the dimensions of buttons to send to a specific spot
            SCREEN = HIGHSCORE;
        }
        else if(SCREEN == INTRO && mx > 1300 && mx < 1739 && my > 850 && my < 949){
            SCREEN = SHOP;
        }
        else if(SCREEN == DEADSCREEN && player.getPlayerCondition() && mx > 727 && mx < 935 && my > 700 && my < 755 ){    //g.drawRect(727,700, 208, 55);   g.drawRect(997,700, 208, 55);
            SCREEN = GAME;     // Resetting the game
            player = new Player();
            offset = 0;
            livesCounter = 5;
            killCount = 0;
            score = 0;
            enemy = new Enemy(2200);
            bats = new bat(2700);
            speed = 10;
            randomLocationZombie = randint(1920, 3080);
            randomLocationBat = randint(1920, 3080);
            EnemyArrayList = new ArrayList<>();
            batArrayList = new ArrayList<>();
            killCountList = new ArrayList<>();
            batArrayList.add(bats);
            EnemyArrayList.add(enemy);
        }
        else if(SCREEN == DEADSCREEN && !player.getPlayerCondition() && mx > 727 && mx < 935 && my > 700 && my < 755 ){    //g.drawRect(727,700, 208, 55);   g.drawRect(997,700, 208, 55);
            SCREEN = GAME;    // Resetting the game
            player = new Player();
            offset = 0;
            livesCounter = 5;
            goalAmount += 5;
            killCount = 0;
            score = 0;
            enemy = new Enemy(2200);
            bats = new bat(2700);
            speed = 10;
            randomLocationZombie = randint(1920, 3080);
            randomLocationBat = randint(1920, 3080);
            EnemyArrayList = new ArrayList<>();
            batArrayList = new ArrayList<>();
            killCountList = new ArrayList<>();
            batArrayList.add(bats);
            EnemyArrayList.add(enemy);
        }
        else if(SCREEN == DEADSCREEN && !player.getPlayerCondition() && mx > 997 && mx < 1205 && my > 700 && my < 755 ){    //g.drawRect(727,700, 208, 55);   g.drawRect(997,700, 208, 55);
            SCREEN = INTRO;    // Resetting the game
            player = new Player();
            offset = 0;
            livesCounter = 5;
            goalAmount += 5;
            killCount = 0;
            score = 0;
            enemy = new Enemy(2200);
            bats = new bat(2700);
            speed = 10;
            randomLocationZombie = randint(1920, 3080);
            randomLocationBat = randint(1920, 3080);
            EnemyArrayList = new ArrayList<>();
            batArrayList = new ArrayList<>();
            killCountList = new ArrayList<>();
            batArrayList.add(bats);
            EnemyArrayList.add(enemy);
        }
        else if(SCREEN == DEADSCREEN && player.getPlayerCondition() && mx > 997 && mx < 1205 && my > 700 && my < 755 ){    //g.drawRect(727,700, 208, 55);   g.drawRect(997,700, 208, 55);
            SCREEN = INTRO;    // Resetting the game
            player = new Player();
            offset = 0;
            livesCounter = 5;
            killCount = 0;
            score = 0;
            enemy = new Enemy(2200);
            bats = new bat(2700);
            speed = 10;
            randomLocationZombie = randint(1920, 3080);
            randomLocationBat = randint(1920, 3080);
            EnemyArrayList = new ArrayList<>();
            batArrayList = new ArrayList<>();
            killCountList = new ArrayList<>();
            batArrayList.add(bats);
            EnemyArrayList.add(enemy);
        }
        else if(SCREEN == SHOP && mx > 180 && mx < 790 && my > 0 && my < 1080 ){    // Setting the skin according to click in the shop    // g.drawRect(180, 0, 610, 1080);            g.drawRect(1000, 0, 610, 1080);
            player.setSKIN(0);
        }
        else if(SCREEN == SHOP && mx > 1000 && mx < 1610 && my > 0 && my < 1080){
            player.setSKIN(1);
        }
        else if(SCREEN == INTRO && mx > 50 && mx < 180 && my > 20 && my < 120 ){
            muteNoise = 1;
        }

            backButton();
    }
    public void mouseReleased(MouseEvent e) {    // Required method
    }
    public void backButton(){    // Button leading you to the main menu
        if(SCREEN == HIGHSCORE || SCREEN == SHOP) {///g.fillRect(10,20,80,80);
            if (mx > 10 && mx < 110 && my > 20 && my < 100) {
                SCREEN = INTRO;
            }
        }
    }
    @Override
    public void keyTyped(KeyEvent e) {    // Required method

    }

    @Override
    public void keyPressed(KeyEvent e) {    // Required Method
        int key = e.getKeyCode();
        keys[key] = true;
    }

    public void moveBackground() {    // Method responsible for infinitly scrolling the background (Example posted in edsby)
        offset -= speed;
        if (offset <= -1900) {
            offset = 0;
        }
    }
    public void keyInput() {    // Method responsible for tracking all key inputs
        if(SCREEN == GAME) {
            if (keys[KeyEvent.VK_SPACE]) {    // checking for jumping
                if (player.getPlayerY() >= 860) {
                    player.setJumpCounter(10);// g.drawRect(700,850,439,99); if(mx > 700 && mx < 1139 && my > 850 && my < 1289)
                }
            }
        }
        if(SCREEN == GAME) {    // checking for Sliding
            if (keys[KeyEvent.VK_S]) {
                player.playerSlide();
                if(muteNoise == 0) {
                    sounds.slidingPlay();    // Playing the sliding sound
                }
            }
        }
        if(SCREEN == GAME) {
            if (keys[KeyEvent.VK_F]) {    // allowing you to attack
                player.attack();
                if(muteNoise == 0) {
                    sounds.slashPlay();    // Playing the slash sound
                }
            }
        }
        if(SCREEN == GAME) {    // Rest of misc calls used in the program
            player.gravity();
            player.changeY();
            player.checkSlide();
            player.changeHitbox();
            moveAll();
        }
    }

    public void moveAll() {    // Method responsible for moving the enemy towards you
        for (int i = 0; i <= EnemyArrayList.size() - 1; i++) {    // Moving the Enemy at each index
            EnemyArrayList.get(i).movement(speed);
        }
        for (int i = 0; i <= batArrayList.size() - 1; i++) {    // Moving the bat at each index
            batArrayList.get(i).movement(speed);
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {    // Required Method
        int key = e.getKeyCode();
        keys[key] = false;
    }

    public static int randint(double low, double high) {    // Method responsible for the randomization (used in the past)
        return (int) (Math.random() * (high - low + 1) + low);
    }

    public void spawnMobs() {    // Method responsible for spawning the enemies
        for (int i = 0; i <= EnemyArrayList.size() - 1; i++) {    // Looping through each index in the array List
            if (EnemyArrayList.get(i).getX() <= 0) {
                EnemyArrayList.remove(i);    // Removed from list when reach 0
                killCheckCounter = 0;
                if (EnemyArrayList.size() == 0) {    // Refreshing the game with enemies
                    EnemyArrayList.add(new Enemy(1960 + randint(1200, 1600)));    // Randomly adding at positions to allow for a better gameplay
                    EnemyArrayList.add(new Enemy(randomLocationZombie));
                }
            }
        }
        for (int i = 0; i <= batArrayList.size() - 1; i++) {    // Looping through batArrayList to check if they are off screen to remove them from array list, speed purposes so don't have to loop through off screen mobs
            if (batArrayList.get(i).getBatX() <= 0) {    // Removing each bat when they reach 0 X
                batArrayList.remove(i);
            }
            if(batArrayList.size() == 0){    // Adding new bats when arrayList hits 0 in size
                batArrayList.add(new bat(randomLocationBat));
            }
        }
    }

    public void collision() {    // Method responsible for checking collisions between the player and the mobs
        for (int i = 0; i <= EnemyArrayList.size() - 1; i++) {    // Looping through player and enemy body arraylist
            if (!EnemyArrayList.get(i).getCondition()) {
                if (player.getHitboxHead().intersects(EnemyArrayList.get(i).getEnemyBody()) || player.getHitboxBody().intersects(EnemyArrayList.get(i).getEnemyBody())) {    // Checking both players hitboxs if intersect with each enemy at each index
                    player.dead();    // Killing the player when intersecting (Using rectangle collision)
                    EnemyArrayList.get(i).attack();
                    speed = 0;
                    SCREEN = DEADSCREEN;
                    if(muteNoise == 0) {
                        sounds.deathPlay();    // Death noise if mute is not activated
                    }
                }
            }
        }
        for (int i = 0; i <= EnemyArrayList.size() - 1; i++) {    // Looping through player sword and enemy array list   (I dont remove from the array list when zombies die because I want the death animation to be there)
            if (player.getHitboxAttack().intersects(EnemyArrayList.get(i).getEnemyBody()) && player.getAttack()) {    // Checking the players attack hitbox if it falls on each enemy in the array list
                EnemyArrayList.get(i).die();    // Killing each enemy that intersected with the attack hitbox after checking each index
                if(killCheckCounter == 0){    // Adding a kill every time
                    killCount++;
                    killCheckCounter++;
                    totalKillCount += killCount;
                }
                if(killCount == goalAmount){
                    SCREEN = DEADSCREEN;
                    goalAmount += 5;
                }
            }
        }
        for(int i = 0; i <= batArrayList.size() - 1; i++){    // Looping through bat body array list and player
            if (player.getHitboxHead().intersects(batArrayList.get(i).getBatHitbox()) || player.getHitboxBody().intersects(batArrayList.get(i).getBatHitbox())) {    // Checking the players head and body hit box with each bat in the array list
                player.dead();    // Killing the player
                sounds.deathPlay();    // Playing the noise
                speed = 0;    // Offset will add by 0, therefore won't move
                bats.flee();    // Bat will go up in Y
                SCREEN = DEADSCREEN;
                livesCounter = 0;

            }
        }
        for(int i = 0; i <= batArrayList.size() - 1; i++){    // Looping through array list of bats and player sword
            if (player.getHitboxAttack().intersects(batArrayList.get(i).getBatHitbox()) && player.getAttack()) {    // Using the array list to loop through each bat and players attack to increase speed (game mechanic)
                if(speed <= 35) {    // Speed must be less that 35 or player will die because of the lives mechanic
                    speed += 5;
                    livesCounter -= 1;
                }
                if(speed == 35){
                    player.dead();    // Killing the player if it attacks 5 bats
                    speed = 0;
                    bats.flee();
                    SCREEN = DEADSCREEN;
                    livesCounter = 0;
                }
                batArrayList.get(i).flee();    // Fleeing each bat that gets attacked (checking the array List)
            }
        }
    }
    public void countScore() {    // Method responsible for counting score according to speed
        if (!player.getPlayerCondition()){    // If player is alive, the score system will come into play
            score += speed / 5;
        }
        scoresNumber = Integer.parseInt(scores);    // Checking the highscore system to see if the old written score is below or above the new one and acts accordingly
        if(scoresNumber < score){    // Since scores is a string, I must use parseInt to convert
            scoresNumber = score;
        }

    }


    public void drawMob(Graphics g){    // Method responsible for drawing mob
        for (int i = 0; i <= EnemyArrayList.size() - 1; i++) {    // Looping through enemy array list to display each one
            EnemyArrayList.get(i).drawEnemy(g);    // Gets the enemy at i and uses the draw Enemy method for it
        }
        for (int i = 0; i <= batArrayList.size() - 1; i++) {    // Looping through bat array list to display
            batArrayList.get(i).drawBat(g);    // Gets the Bat at i and uses the draw Enemy method for it
        }
    }
    public void drawIntro(Graphics g){    // Method responsible for displaying the intro screen
        g.drawImage(introBackground,0,0,null);
        g.setColor(Color.WHITE);
        g.setFont(scoreFont);
        g.drawString("" + kills, 1650, 50);
        g.setColor(Color.GREEN);

        try{    // Using try and catch to have a hover on each button
            if(new Rectangle(700,850,439,99).contains(getMousePosition())){
                g.fillRect(698,848,445,105);
            }

        }catch(Exception e){
        }

        try{
            if(new Rectangle(100,850,439,99).contains(getMousePosition())){
                g.fillRect(98,848,445,105);
            }

        }catch(Exception e){
        }
        g.drawImage(highscoreButton,100,850,null);
        g.drawImage(playButton,700,850,null);
        try{
            if(new Rectangle(1300,850,439,99).contains(getMousePosition())){
                g.fillRect(1298,848,445,105);
            }
        }catch(Exception e){
        }
        g.drawImage(skinButton,1300,850,null);
        g.drawImage(headCount,1510,10,null);
        g.drawImage(mute,50,20,null);
        g.drawRect(50,20,130,100);

    }

    @Override
    public void paint(Graphics g) {// Method responsible for displaying the graphics on screen
        if(SCREEN == INTRO){
            drawIntro(g);
        }
        else if(SCREEN == GAME) {    // Displaying game screen
            g.drawImage(bg, offset, 0, null);
            g.drawImage(bg, offset + 1900, 0, 1920, 1080, null);
            g.drawImage(bg, offset + 1900, 0, null);
            g.drawImage(bg, offset + 3800, 0, 1920, 1080, null);
            player.drawPlayer(g);
            g.setColor(Color.WHITE);
            g.setFont(lives);
            g.drawString("Lives to Bats: " + livesCounter,150,100);
            g.drawString(" " + killCount + "/ " + goalAmount,1700,100);
            g.drawString("Score: " + score,150,300);

            drawMob(g);
            g.drawImage(headCount,1510,10,null);
        }
        else if(SCREEN == HIGHSCORE){    // Displaying highscore screen
            g.drawImage(bg,0,0,null);
            g.fillRect(10,20,80,80);
            g.drawImage(backButton,15,20,null);
            g.drawImage(highScoreDisplay,470,200,null);
            g.setFont(scoreFont);
            g.setColor(Color.WHITE);
            g.drawString(scores,800,390);
            g.drawString(kills,800,515);
        }
        else if (SCREEN == DEADSCREEN){    // Displaying dead screen
            g.drawImage(bg, offset, 0, null);
            g.drawImage(bg, offset + 1900, 0, 1920, 1080, null);
            g.drawImage(bg, offset + 1900, 0, null);
            g.drawImage(bg, offset + 3800, 0, 1920, 1080, null);
            player.drawPlayer(g);
            drawMob(g);
            g.setColor(Color.CYAN);
            g.setFont(lives);
            g.drawImage(deathScreen,670,400,null);


            g.drawImage(headCount,1510,10,null);
            g.drawString("Lives to Bats: " + livesCounter,150,100);
            g.drawString("" + score,920,515);
            g.drawString("" + killCount,920,623);

        }
        else if(SCREEN == SHOP){    // Displaying shop screen
            g.drawImage(bg,0,0,null);
            g.drawImage(ninjaLocked,0,0,null);
            g.drawImage(girlNinjaSelect,820,0,null);
            g.setColor(Color.GREEN);
            if(player.getSkin() == 1) {    // Showing the select outline accordingly
                g.drawRect(1000, 0, 610, 1080);
            }
            else {
                g.drawRect(180, 0, 610, 1080);

            }
            g.fillRect(10,20,80,80);
            g.drawImage(backButton,15,20,null);    // Drawing back Button
        }




    }
}

class Player {    // Class responsible for the player and everything he can do
    private double gravity;
    private Image[] images, imagesJump, imagesSlide, imagesAttack,imagesDeath,imagesSkin2, imagesJumpSkin2, imagesSlideSkin2, imagesAttackSkin2,imagesDeathSkin2;
    private int frame, frameJump,frameDeath,deathDelay, runDelay, jumpDelay, slideDelay, frameSlide, slideDelayTwo, frameAttack, attackDelay,jumpCounter,playerX,playerY, SKIN;
    private int frameAttackSkin2,frameJumpSkin2,frameSkin2,frameDeathSkin2,frameSlideTwo,deathDelayTwo,runDelayTwo;
    private boolean FALLING = false, SLIDING = false, ATTACK = false,DEAD = false;
    private final int groundLevel = 860;
    private Rectangle hitboxHead, hitboxBody, hitboxAttack;




    public Player() {    // Player constructor
        playerX = 650;
        playerY = groundLevel;
        frame = 0;
        SKIN = 1;
        frameSlide = 0;
        runDelay = 0;
        frameJump = 0;
        images = new Image[6];    // loading data structure, Image array
        imagesAttack = new Image[4];
        imagesSlide = new Image[5];
        imagesJump = new Image[10];
        imagesDeath = new Image[7];
        imagesSkin2 = new Image[10];
        imagesDeathSkin2 = new Image[10];
        imagesJumpSkin2 = new Image[10];
        imagesSlideSkin2 = new Image[9];
        imagesAttackSkin2 = new Image[10];
        frameSkin2 = 0;
        frameDeathSkin2 = 0;
        frameSlideTwo = 0;
        frameAttackSkin2 = 0;
        frameJumpSkin2 = 0;
        gravity = 15;
        hitboxHead = new Rectangle(); //(playerX + 45, playerY + 5, 50, 55);
        hitboxBody = new Rectangle(); //(playerX + 15, playerY + 60, 55, 60);
        hitboxAttack = new Rectangle();
        getImagesRun();    // Loading all the animations into the constructor
        getImagesJump();
        getImagesSlide();
        getImagesAttack();
        getImagesDeath();
        getImagesAttackSkin2();
        getImagesDeathSkin2();
        getImagesSlideSkin2();
        getImagesRunSkin2();
        getImagesJumpSkin2();
    }
    public int getSkin(){
        return SKIN;
    }    // Following OOP rules, setting the skin to a different version
    public void setSKIN(int SKIN){
        this.SKIN = SKIN;
    }
    public void getImagesRun() {    // Loading the running animations
        for (int i = 0; i <= images.length - 1; i++) {
            images[i] = new ImageIcon("Player/Run" + i + "_ccexpress.png").getImage();
        }
    }
    public void getImagesDeath() {    // Loading the death animations
        for (int i = 0; i <= imagesDeath.length - 1; i++) {
            imagesDeath[i] = new ImageIcon("Player/Dead__00" + i + "_ccexpress.png").getImage();
        }
    }

    public void getImagesAttack() {    // Loading the attack animations
        for (int i = 0; i <= imagesAttack.length - 1; i++) {
            imagesAttack[i] = new ImageIcon("Player/Attack" + i + ".png").getImage();
        }
    }

    public void getImagesJump() {    // Loading the jumping animations
        for (int i = 0; i <= imagesJump.length - 1; i++) {
            imagesJump[i] = new ImageIcon("Player/Jump" + i + "_ccexpress.png").getImage();
        }
    }

    public void getImagesSlide() {    // Loading the sliding animations
        for (int i = 0; i <= imagesSlide.length - 1; i++) {
            imagesSlide[i] = new ImageIcon("Player/Slide__00" + i + "_ccexpress.png").getImage();
        }
    }
    public void getImagesRunSkin2() {    // Loading the running animations for the second skin
        for (int i = 0; i <= imagesSkin2.length - 1; i++) {
            imagesSkin2[i] = new ImageIcon("Player/Skin1/" + i + "run.png").getImage();
        }
    }
    public void getImagesDeathSkin2() {    // Loading the death animation for the second skin
        for (int i = 0; i <= imagesDeathSkin2.length - 1; i++) {
            imagesDeathSkin2[i] = new ImageIcon("Player/Skin1/" + i + "dead.png").getImage();
        }
    }

    public void getImagesAttackSkin2() {    // Loading the attack animations for the second skin
        for (int i = 0; i <= imagesAttackSkin2.length - 1; i++) {
            imagesAttackSkin2[i] = new ImageIcon("Player/Skin1/" + i + "attack.png").getImage();
        }
    }

    public void getImagesJumpSkin2() {    // Loading the jumping animations for the second skin
        for (int i = 0; i <= imagesJumpSkin2.length - 1; i++) {
            imagesJumpSkin2[i] = new ImageIcon("Player/Skin1/" + i + "jump.png").getImage();
        }
    }

    public void getImagesSlideSkin2() {    // Loading the slide animations for the second skin
        for (int i = 0; i <= imagesSlideSkin2.length - 1; i++) {
            imagesSlideSkin2[i] = new ImageIcon("Player/Skin1/" + i + "slide.png").getImage();
        }
    }


    public void setJumpCounter(int counter) {
        this.jumpCounter = counter;
    }    // Setter for jump counter

    public void changeY() {    // changing the players position when space bar is clicked
        if (jumpCounter > 0 && !DEAD) {
            playerY -= 35;
            jumpCounter -= 1;
        }
    }
    public void changeHitbox(){    // Moving the hitbox according to the players movements
        hitboxHead = new Rectangle(playerX + 45, playerY + 5, 50, 55);
        hitboxBody = new Rectangle(playerX + 15, playerY + 60, 55, 60);
        hitboxAttack = new Rectangle(playerX + 95,playerY - 5,45,125);

    }
    public Rectangle getHitboxHead(){
        return hitboxHead;
    }    // Getter for the hitbox of the players head
    public Rectangle getHitboxBody(){
        return hitboxBody;
    }    // Getter for the hitbox of the players body

    public int getPlayerY() {
        return playerY;
    }    // Getter for players Y

    public void gravity() {    // Applying gravity when above ground
        if (FALLING) {
            playerY += gravity;
        }
        if (playerY > groundLevel) {
            FALLING = false;
            playerY = groundLevel;
        }
        if (playerY < groundLevel) {
            FALLING = true;
            SLIDING = false;
        }
    }

    public void attack() {    // Attacking when F is clicked
        if (playerY == groundLevel && !ATTACK) {
            ATTACK = true;
        }
    }
    public void updateAnimationDeath(){    // Updating the death animation
        if (deathDelay == 0) {
            frameDeath++;
            deathDelay = 6;
            if (frameDeath == imagesDeath.length - 1) {
                frameDeath = imagesDeath.length - 2;
            }
        }
        deathAnimationDelay();
    }
    public void dead(){    // Killing the player when collisions occur
        DEAD = true;
        FALLING = false;
        playerX += 15;
    }
    public void updateAnimationRun() {    // Updating the run animation
        if (runDelay == 0) {
            frame++;
            runDelay = 2;
            if (frame == images.length) {
                frame = 0;
            }
        }
        runAnimationDelay();
    }
    public void updateAnimationRunSkin2() {    // Updating the run animation for the second skin
        if (runDelayTwo == 0) {
            frameSkin2++;
            runDelayTwo = 2;
            if (frameSkin2 == imagesSkin2.length) {
                frameSkin2 = 0;
            }
        }
        runAnimationDelayTwo();
    }
    public void updateAnimationJumpSkin2() {    // Updating the jump animation for the second skin
        if (jumpDelay == 0) {
            frameJumpSkin2++;
            jumpDelay = 2;
            if (frameJumpSkin2 == imagesJumpSkin2.length) {
                frameJumpSkin2 = 0;
            }
        }
        jumpAnimationDelay();
    }
    public void updateAnimationSlideSkin2() {    // Updating the slide animation for the second skin
        if (slideDelay == 0) {
            frameSlideTwo++;
            slideDelay = 2;
            if (frameSlideTwo == imagesSlideSkin2.length - 1) {
                frameSlideTwo = 0;
            }
        }
        slideAnimationDelay();
    }
    public void updateAnimationAttackSkin2() {    // Updating the attack animation for the second skin
        if (attackDelay == 0) {
            frameAttackSkin2++;
            attackDelay = 2;
            if (frameAttackSkin2 == imagesAttackSkin2.length) {
                frameAttackSkin2 = 0;
                ATTACK = false;
            }
        }
        attackAnimationDelay();
    }
    public void updateAnimationDeadSkin2() {    // Updating the dying animation for the second skin
        if (deathDelay == 0) {
            frameDeathSkin2++;
            deathDelayTwo = 2;
            if (frameDeathSkin2 == imagesDeathSkin2.length) {
                frameDeathSkin2 = imagesDeathSkin2.length - 2;

            }
        }
        deathAnimationDelay2();
    }
    public boolean getPlayerCondition(){
        return DEAD;
    }    // Getter to see if the player is dead
    public void deathAnimationDelay(){    // Death Animation Delay
        if(deathDelay > 0){
            deathDelay -= 1;
        }
    }
    public void deathAnimationDelay2(){    // Death animation for second skin
        if(deathDelayTwo > 0){
            deathDelayTwo -= 1;
        }
    }
    public void checkSlide() {    // Checking if conditions apply and allowing the user to slide
        if (SLIDING && !DEAD) {
            slideDelayTwo++;
            playerY = groundLevel + 30;
            if (slideDelayTwo == 20) {
                SLIDING = false;
                slideDelayTwo = 0;
            }
        }
    }
    public void playerSlide(){
        SLIDING = true;
    }    // Setting slide to true
    public void runAnimationDelay(){    // Applying a running animation delay
        if(runDelay > 0){
            runDelay -= 1;
        }
    }
    public void runAnimationDelayTwo(){     // Applying a running animation delay for the second skin
        if(runDelayTwo > 0){
            runDelayTwo -= 1;
        }
    }
    public void jumpAnimationDelay(){    // Jump animation delay
        if(jumpDelay > 0){
            jumpDelay -= 1;
        }
    }
    public void slideAnimationDelay(){    // Slide animation delay
        if(slideDelay > 0){
            slideDelay -= 1;
        }
    }

    public void updateAnimationAttack() {    // Updating the attack animation
        if(attackDelay == 0) {
            frameAttack++;
            attackDelay = 3;
            if (frameAttack == imagesAttack.length) {
                frameAttack = 0;
                ATTACK = false;
            }
        }
        attackAnimationDelay();
    }
    public boolean getAttack(){
        return ATTACK;
    }    // Getting the current condition of the attack, used for collisions

    public Rectangle getHitboxAttack(){
        return hitboxAttack;
    }    // Returning the hitbox for attack
    public void attackAnimationDelay(){    // applying a attack animation delay
        if(attackDelay > 0){
            attackDelay -= 1;
        }
    }
    public void updateAnimationJump() {    // Updating the jump animation
        if(jumpDelay == 0){
            frameJump++;
            jumpDelay = 2;
        }
        if (frameJump == imagesJump.length) {
            frameJump = 0;
        }
        jumpAnimationDelay();
    }
    public void updateAnimationSlide() {    // Updating the slide animation
        if(slideDelay == 0){
            frameSlide++;
            slideDelay = 1;
        }
        if(frameSlide == imagesSlide.length) {
            frameSlide = 0;
        }
        slideAnimationDelay();
    }

    public void drawPlayer(Graphics g) {    // Method responsible for drawing the player with appropriate animations
        updateAnimationRun();
        updateAnimationJump();
        updateAnimationSlide();
        updateAnimationAttack();
        updateAnimationDeath();

        updateAnimationRunSkin2();
        updateAnimationJumpSkin2();
        updateAnimationSlideSkin2();
        updateAnimationAttackSkin2();
        updateAnimationDeadSkin2();
        if (FALLING && SKIN == 0) {    // If its a certain skin doing a certain action, it will draw accordingly
            g.drawImage(imagesJump[frameJump], playerX, playerY, null);
        }
        else if(DEAD && SKIN == 0){
            g.drawImage(imagesDeath[frameDeath], playerX, playerY, null);

        }
        else if(SLIDING && SKIN == 0) {
            g.drawImage(imagesSlide[frameSlide], playerX, playerY, null);

        }
        else if(ATTACK && SKIN == 0){
            g.drawImage(imagesAttack[frameAttack],playerX,playerY,null);
        }
        else if (!FALLING && SKIN == 0){
            g.drawImage(images[frame], playerX, playerY, null);
        }
        if (FALLING && SKIN == 1) {
            g.drawImage(imagesJumpSkin2[frameJumpSkin2], playerX, playerY, null);
        }
        if(DEAD && SKIN == 1){
            g.drawImage(imagesDeathSkin2[frameDeathSkin2], playerX, playerY, null);

        }
        else if(SLIDING && SKIN == 1) {
            g.drawImage(imagesSlideSkin2[frameSlideTwo], playerX, playerY, null);

        }
        else if(ATTACK && SKIN == 1){
            g.drawImage(imagesAttackSkin2[frameAttackSkin2],playerX,playerY,null);
        }
        else if (!FALLING && SKIN == 1){
            g.drawImage(imagesSkin2[frameSkin2], playerX, playerY, null);
        }


    }
}
class Enemy{    // Class responsible for the zombie enemy to appear on screen and all the functions it has
    private Image[] images,imagesDead, imagesAttack;
    private int frame,frameAttack,attackDelay,idleDelay,frameDead,deadDelay,enemyX,enemyY, killCount,speed;
    private boolean PROVOKED = false, DEAD = false, killCountCheck = false;
    private Rectangle enemyBody;


    public Enemy(int enemyX){    // Constructor for the enemy class, constructing the enemy at a certain X and gets its animations
        frame = 0;
        this.enemyX = enemyX;
        enemyY = 860;
        enemyBody = new Rectangle();
        images = new Image[6];
        imagesDead = new Image[7];
        imagesAttack = new Image[4];
        getImages();
        getImagesAttack();
        getImagesDead();

    }
    public void getImages() {    // Getting the idle animation for the zombie
        for (int i = 0; i <= images.length - 1; i++) {
            images[i] = new ImageIcon("Enemy/Zombie/Idle" + i + ".png").getImage();
        }
    }
    public void getImagesAttack() {    // Loading the attack animation for the zombie
        for (int i = 0; i <= imagesAttack.length - 1; i++) {
            imagesAttack[i] = new ImageIcon("Enemy/Zombie/Attack" + i + ".png").getImage();
        }
    }
    public void getImagesDead(){    // Loading the death animations for the zombie
        for (int i = 0; i <= imagesDead.length - 1; i++) {
            imagesDead[i] = new ImageIcon("Enemy/Zombie/Dead" + i + ".png").getImage();
        }
    }

    public void movement(int speed){    // Method responsible for moving the zombie, has a parameter to ensure it moves at the same speed as the screen
        this.speed = speed;
        enemyX -= speed;
        enemyBody = new Rectangle(enemyX+ 30,enemyY + 25,50,90);
    }

    public void updateAnimationIdle() {    // Updating the idle animation
        if(idleDelay == 0) {
            frame++;
            idleDelay = 5;
            if (frame == images.length) {
                frame = 0;
            }
        }
        idleAnimationDelay();
    }
    public void updateAnimationAttack() {    // Updating the attack animation
        if(attackDelay == 0) {
            frameAttack++;
            attackDelay = 10;
            if (frameAttack == imagesAttack.length) {
                frameAttack = imagesAttack.length - 1;
                PROVOKED = false;
            }
        }
        attackAnimationDelay();
    }
    public boolean getCondition(){
        return DEAD;
    }    // Getting the condition for the zombie
    public void updateAnimationDead() {    // Updating the death animation for the zombie
        if(deadDelay == 0) {
            frameDead++;
            deadDelay = 5;
            if (frameDead == imagesDead.length) {
                frameDead = imagesDead.length - 1;
            }
        }
        deadAnimationDelay();
    }
    public void idleAnimationDelay(){    // adding a delay for the idle animation
        if(idleDelay > 0){
            idleDelay -= 1;
        }
    }
    public void attackAnimationDelay(){    // Attacking animation Delay
        if(attackDelay > 0){
            attackDelay -= 1;
        }
    }
    public void attack(){
        PROVOKED = true;
    }    // Setting provoked to true when killing the enemy

    public void deadAnimationDelay(){    // Adding a delay to the death animation
        if(deadDelay > 0){
            deadDelay -= 1;
        }
    }
    public void die(){    // Killing the zombie when the player attacks
        DEAD = true;
        enemyY += 3;    // So the zombie looks like its dying on the ground not the air
    }

    public Rectangle getEnemyBody(){
        return enemyBody;
    }    // Getting the hitbox of the enemies body

    public void drawEnemy(Graphics g){    // Drawing the enemy based on certain conditions set above
        updateAnimationIdle();
        updateAnimationDead();
        updateAnimationAttack();
        if(DEAD){
            g.drawImage(imagesDead[frameDead], enemyX , enemyY, null);
        }
        else if(PROVOKED){
            g.drawImage(imagesAttack[frameAttack], enemyX , enemyY, null);
        }
        else {
            g.drawImage(images[frame], enemyX , enemyY, null);
        }
        g.setColor(Color.GREEN);
    }
    public int getX(){
        return enemyX;
    }    // Method responsible for getting the X of the enemy
}
class bat{    // Class responsible for the bat and everything it can do
    private int batX,batY,frame,delay,speed;
    private boolean FLEE;
    private Rectangle batHitbox;
    private Image [] images;

    public bat(int batX){    // Method responsible for constructing the bat and its X
        this.batX = batX;
        batY = 760;
        delay = 0;
        frame = 0;
        images = new Image[10];
        batHitbox = new Rectangle();
        getImages();
    }
    public void getImages() {    // Loading the animation for the bat
        for (int i = 0; i <= images.length - 1; i++) {
            images[i] = new ImageIcon("Enemy/Bat/" + i + "bat.png").getImage();
        }
    }
    public void updateAnimation() {    // Updating the animations for the bat
        if(delay == 0) {
            frame++;
            delay = 2;
            if (frame == images.length - 1) {
                frame = 1;
            }
        }
        animationDelay();
    }
    public void animationDelay(){    // applying an animation Delay
        if(delay > 0){
            delay -= 1;
        }
    }
    public void movement(int speed){    // Moving the bat at a speed equal to the screens speed
        this.speed = speed;
        batX -= speed;
        batHitbox = new Rectangle(batX + 10,batY + 20,100,100);
    }
    public void flee(){    // when bat gets attacked, it moves up the Y and this method is responsible for that
        FLEE = true;
        batY -= 60;
    }
    public Rectangle getBatHitbox(){
        return batHitbox;
    }    // Getting the bats hitbox
    public int getBatX(){
        return batX;
    }    // Getting the bats X
    public void drawBat(Graphics g){    // Drawing the bat
        updateAnimation();
        g.drawImage(images[frame],batX,batY,null);
    }
}
class Sound implements ActionListener {    // Method responsible for all audio in game
    AudioClip sound1;
    AudioClip sound2;
    AudioClip sound3;

    public Sound(File wavFile1, File wavFile2, File wavFile3, File wavFile4) {    // Method responsible for playing the three sounds for different scenarios

        try {
            sound1 = Applet.newAudioClip(wavFile1.toURL());    // All the sounds I used loading in
            sound2 = Applet.newAudioClip(wavFile2.toURL());
            sound3 = Applet.newAudioClip(wavFile3.toURL());

        } catch (Exception e) {    // Catching exception
            e.printStackTrace();
        }
    }

    public void actionPerformed(ActionEvent ae) {    // Action performed method for the sounds
    }

    public void slashPlay() {    // Method responsible for playing the shot noise
        sound1.play();
    }

    public void deathPlay() {    // Method responsible for playing the death noise
        sound2.play();
    }    // method responsible for playing the death noise

    public void slidingPlay() {    // Method responsible for playing the thrust noise
        sound3.play();
    }    // method responsible for playing the sliding noise
}







